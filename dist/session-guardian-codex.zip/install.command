#!/bin/bash
# session-guardian 离线安装器（无需联网）
# 双击运行，把同目录下的两个技能装到 Codex。
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=============================================="
echo "  session-guardian 技能包 离线安装"
echo "=============================================="
echo ""
echo "▶ 安装两个技能……"
mkdir -p "$HOME/.codex/skills"
rm -rf "$HOME/.codex/skills/session-observer" "$HOME/.codex/skills/context-handoff"
cp -R "$DIR/session-observer" "$HOME/.codex/skills/session-observer"
cp -R "$DIR/context-handoff"   "$HOME/.codex/skills/context-handoff"
echo "   技能已复制到 ~/.codex/skills/"

echo "▶ 写入常驻规则……"
mkdir -p "$HOME/.codex/rules"
touch "$HOME/.codex/rules/default.rules"
cat "$DIR/session-observer/adapters/codex/rules.snippet.md" >> "$HOME/.codex/rules/default.rules"
cat "$DIR/context-handoff/adapters/codex/rules.snippet.md" >> "$HOME/.codex/rules/default.rules"
echo "   规则已写入 ~/.codex/rules/default.rules"

echo ""
echo "=============================================="
echo "  ✅ 安装完成！"
echo "  完全退出 Codex 再打开，发一句「观察」验证。"
echo "=============================================="
echo ""
[ -t 0 ] && read -p "按回车关闭…" _
