#!/bin/bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "=============================================="
echo "  session-guardian 技能包 离线安装"
echo "=============================================="
echo ""
echo "▶ 安装两个技能……"
mkdir -p "$HOME/.codex/skills"
rm -rf "$HOME/.codex/skills/session-observer" "$HOME/.codex/skills/context-handoff"
cp -R "$DIR/session-observer" "$HOME/.codex/skills/session-observer"
cp -R "$DIR/context-handoff"   "$HOME/.codex/skills/context-handoff"
# Codex 只认 name+description，剥掉 DSH 专属的 whenToUse
for f in "$HOME/.codex/skills/session-observer/SKILL.md" "$HOME/.codex/skills/context-handoff/SKILL.md"; do
  if [ -f "$f" ] && grep -q '^whenToUse:' "$f" 2>/dev/null; then
    grep -v '^whenToUse:' "$f" > "$f.tmp" && mv "$f.tmp" "$f"
  fi
done
echo "   技能已复制到 ~/.codex/skills/"
echo "▶ 写入常驻规则……"
mkdir -p "$HOME/.codex/rules"
touch "$HOME/.codex/rules/default.rules"
cat "$DIR/session-observer/adapters/codex/rules.snippet.md" >> "$HOME/.codex/rules/default.rules"
cat "$DIR/context-handoff/adapters/codex/rules.snippet.md" >> "$HOME/.codex/rules/default.rules"
echo "   规则已写入 ~/.codex/rules/default.rules"
echo ""
echo "=============================================="
echo "  ✅ 安装完成！"
echo "  完全退出 Codex（Cmd+Q）再打开，开新会话发「观察」验证。"
echo "=============================================="
echo ""
[ -t 0 ] && read -p "按回车关闭…" _
